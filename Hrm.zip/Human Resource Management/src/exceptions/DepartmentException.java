package exceptions;

public class DepartmentException  extends Exception{
	
public DepartmentException() 
	{
		
		
	}

	public DepartmentException( String message) {
		super( message);
		
	}

}
