package model;

public class Leave {
	private String employee_firstName;
	private String employee_LastName;
	private int  employeeId;
	private String startDate;
	private String endDate;
	private String status;
	private int departmentId;
	public Leave(String employee_firstName, String employee_LastName, int employeeId, String startDate, String endDate,
			String status,int departmentId) {
		super();
		this.employee_firstName = employee_firstName;
		this.employee_LastName = employee_LastName;
		this.employeeId = employeeId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = status;
		this.departmentId=departmentId;
	}
	public Leave() {
		// TODO Auto-generated constructor stub
	}
	public Leave(String status2) {
		// TODO Auto-generated constructor stub
	}
	public String getEmployee_firstName() {
		return employee_firstName;
	}
	public void setEmployee_firstName(String employee_firstName) {
		this.employee_firstName = employee_firstName;
	}
	public String getEmployee_LastName() {
		return employee_LastName;
	}
	public void setEmployee_LastName(String employee_LastName) {
		this.employee_LastName = employee_LastName;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	@Override
	public String toString() {
		return "Leave [employee_firstName=" + employee_firstName + ", employee_LastName=" + employee_LastName
				+ ", employeeId=" + employeeId + ", startDate=" + startDate + ", endDate=" + endDate + ", status="
				+ status + ",departmentId="+departmentId+"]";
	}

}
