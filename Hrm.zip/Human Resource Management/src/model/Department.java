package model;

public class Department {
	private String name;
	private int id;
	public Department(int id,String name) {
		super();
		this.name = name;
		this.id=id;
	}
	

	public Department() {
		// TODO Auto-generated constructor stub
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
public int getId() {
	return id;
	
}
public void setId(int id) {
	this.id=id;
}

	@Override
	public String toString() {
		return "Department [ id="+id+",name=" + name +"]";
	}


}
