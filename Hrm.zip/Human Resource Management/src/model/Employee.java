package model;

import java.io.Serializable;

public class Employee implements Serializable{
	private int employeeId;
	private String employeePassword;
	private String employee_firstName;
	private String employee_LastName;
	private String employee_DateOfBirth;
	private String employee_ContactNo;
	private String employee_EmailID;
	private String employeePermanentAddress;
	private String  employeeCurrentAddress;
	private String employee_DateOfJoining;
	private int employeeDepartment;
	private double employeeSalary;
	private String employee_DateOfExit;
	public Employee() {
		
	}
	public Employee(int employeeId, String employeePassword, String employee_firstName, String employee_LastName,
			String employee_DateOfBirth, String employee_ContactNo, String employee_EmailID,
			String employeePermanentAddress, String employeeCurrentAddress, String employee_DateOfJoining,
			int employeeDepartment, double employeeSalary, String employee_DateOfExit) {
		super();
		this.employeeId = employeeId;
		this.employeePassword = employeePassword;
		this.employee_firstName = employee_firstName;
		this.employee_LastName = employee_LastName;
		this.employee_DateOfBirth = employee_DateOfBirth;
		this.employee_ContactNo = employee_ContactNo;
		this.employee_EmailID = employee_EmailID;
		this.employeePermanentAddress = employeePermanentAddress;
		this.employeeCurrentAddress = employeeCurrentAddress;
		this.employee_DateOfJoining = employee_DateOfJoining;
		this.employeeDepartment = employeeDepartment;
		this.employeeSalary = employeeSalary;
		this.employee_DateOfExit = employee_DateOfExit;
	}
	public Employee( String employeePassword, String employee_firstName, String employee_LastName,
			String employee_DateOfBirth, String employee_ContactNo, String employee_EmailID,
			String employeePermanentAddress, String employeeCurrentAddress, String employee_DateOfJoining,
			int  employeeDepartment, double employeeSalary, String employee_DateOfExit) {
		super();
	
		this.employeePassword = employeePassword;
		this.employee_firstName = employee_firstName;
		this.employee_LastName = employee_LastName;
		this.employee_DateOfBirth = employee_DateOfBirth;
		this.employee_ContactNo = employee_ContactNo;
		this.employee_EmailID = employee_EmailID;
		this.employeePermanentAddress = employeePermanentAddress;
		this.employeeCurrentAddress = employeeCurrentAddress;
		this.employee_DateOfJoining = employee_DateOfJoining;
		this.employeeDepartment = employeeDepartment;
		this.employeeSalary = employeeSalary;
		this.employee_DateOfExit = employee_DateOfExit;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeePassword() {
		return employeePassword;
	}
	public void setEmployeePassword(String employeePassword) {
		this.employeePassword = employeePassword;
	}
	public String getEmployee_firstName() {
		return employee_firstName;
	}
	public void setEmployee_firstName(String employee_firstName) {
		this.employee_firstName = employee_firstName;
	}
	public String getEmployee_LastName() {
		return employee_LastName;
	}
	public void setEmployee_LastName(String employee_LastName) {
		this.employee_LastName = employee_LastName;
	}
	public String getEmployee_DateOfBirth() {
		return employee_DateOfBirth;
	}
	public void setEmployee_DateOfBirth(String employee_DateOfBirth) {
		this.employee_DateOfBirth = employee_DateOfBirth;
	}
	public String getEmployee_ContactNo() {
		return employee_ContactNo;
	}
	public void setEmployee_ContactNo(String employee_ContactNo) {
		this.employee_ContactNo = employee_ContactNo;
	}
	public String getEmployee_EmailID() {
		return employee_EmailID;
	}
	public void setEmployee_EmailID(String employee_EmailID) {
		this.employee_EmailID = employee_EmailID;
	}
	public String getEmployeePermanentAddress() {
		return employeePermanentAddress;
	}
	public void setEmployeePermanentAddress(String employeePermanentAddress) {
		this.employeePermanentAddress = employeePermanentAddress;
	}
	public String getEmployeeCurrentAddress() {
		return employeeCurrentAddress;
	}
	public void setEmployeeCurrentAddress(String employeeCurrentAddress) {
		this.employeeCurrentAddress = employeeCurrentAddress;
	}
	public String getEmployee_DateOfJoining() {
		return employee_DateOfJoining;
	}
	public void setEmployee_DateOfJoining(String employee_DateOfJoining) {
		this.employee_DateOfJoining = employee_DateOfJoining;
	}
	public int getEmployeeDepartment() {
		return employeeDepartment;
	}
	public void setEmployeeDepartment(int employeeDepartment) {
		this.employeeDepartment = employeeDepartment;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	public String getEmployee_DateOfExit() {
		return employee_DateOfExit;
	}
	public void setEmployee_DateOfExit(String employee_DateOfExit) {
		this.employee_DateOfExit = employee_DateOfExit;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeePassword=" + employeePassword + ", employee_firstName="
				+ employee_firstName + ", employee_LastName=" + employee_LastName + ", employee_DateOfBirth="
				+ employee_DateOfBirth + ", employee_ContactNo=" + employee_ContactNo + ", employee_EmailID="
				+ employee_EmailID + ", employeePermanentAddress=" + employeePermanentAddress
				+ ", employeeCurrentAddress=" + employeeCurrentAddress + ", employee_DateOfJoining="
				+ employee_DateOfJoining + ", employeeDepartment=" + employeeDepartment + ", employeeSalary="
				+ employeeSalary + ", employee_DateOfExit=" + employee_DateOfExit + "]";
	}
	
}
