package Features;

public class SpecialFeatures {

	public static void loading() {
		// TODO Auto-generated method stub
		
		System.out.println("loading");
		for(int i=0;i<4;i++) {
			
			System.out.print(".");
		}
		try {
			Thread.sleep(300);
		}
		catch(InterruptedException e) {
			e.printStackTrace();
			
		}
		System.out.println("Done..");
	}
	public static void thankYou() {
		System.out.println();
		
		String str="Thank You...";
		for(int i=0;i<str.length();i++) {
			System.out.println(str.charAt(i));
			if(str.charAt(i)!=' ') {
				try {
					Thread.sleep(200);
				}
				catch(InterruptedException e) {}
		}
		
	}
System.out.println("...........................");
}
}
