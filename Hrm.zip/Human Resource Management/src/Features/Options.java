package Features;

import java.sql.SQLException;
import java.util.Scanner;

import cases.ApplyLeave;
import cases.ChangeEmployeePassWord;
import cases.EmployeeByDepartment;
import cases.GetAllDepartment;
import cases.PendingLeave;
import cases.RegisterDepartment;
import cases.RegisterEmployee;
import cases.TransferEmployee;
import cases.UpdateDepartment;
import cases.UpdateEmployee;
import cases.ViewAllEmployee;
import cases.ViewEmployeeDetail;
import cases.ViewLeaveStatus;
import exceptions.EmployeeException;
import main.EmployeeCase;
import model.Employee;

public class Options {

	public static void adminPanel() throws EmployeeException, Exception {
		// TODO Auto-generated method stub
		
			
			System.out.println();
			System.out.println("------------welcome to admin panel------------");
			Scanner scanner=new Scanner(System.in);
			while(true) {
				System.out.println();

				
				try {
				Thread.sleep(50);
				System.out.println(" +++++++++++++++++++++++++++++++++++++++++++");
				Thread.sleep(50);
				System.out.println("                Choose option");
				Thread.sleep(50);
				System.out.println(" ++++++++++++++++++++++++++++++++++++++++++++++++");
				Thread.sleep(50);
				System.out.println("1.  Add Department          2. View All Department");
				Thread.sleep(50);
				System.out.println("3.  Update Department       4. Add New Employee");
				Thread.sleep(50);
				System.out.println("5.  View All Employee       6. View Leave Request");
				Thread.sleep(50);
				System.out.println("7.  View Employee by ID     8. Update Employee");
				Thread.sleep(50);
				System.out.println("9.  Transfer Employee to other Department");
				Thread.sleep(50);
				System.out.println("10. Employee By Department");
				Thread.sleep(50);
				System.out.println("11. Exit");
				Thread.sleep(50);
				System.out.println("----------------------------------------------");
				} catch (InterruptedException e) {}
				
				int ch = scanner.nextInt();
				
		

				switch(ch) {
				case 1:
					RegisterDepartment.main(null);
					break;
				case 2:
					GetAllDepartment.main(null);
					break;
				case 3:
					UpdateDepartment.main(null);
					break;
				case 4:
					RegisterEmployee.main(null);
					break;
				case 5:
					ViewAllEmployee.main(null);
					break;
				case 6:
					PendingLeave.main(null);
					break;
				case 7:
					System.out.println("Enter ID of Employee");
					int id=scanner.nextInt();
					ViewEmployeeDetail.main(id);
					break;
				case 8:
					System.out.println("Enter ID of Employee");
					int id1=scanner.nextInt();
					UpdateEmployee.main(id1);
					break;
				case 9:
					TransferEmployee.main(null);
					break;
				case 10:
					EmployeeByDepartment.main(null);
					break;
				case 11:
					SpecialFeatures.thankYou();
					return;
					default:
						System.out.println("Wrong Input");
				}

			}
			
		}
	

	public static void employeePanel(Employee employee)  {
		System.out.println();
	System.out.println("WELCOME "+employee.getEmployee_firstName()+" "+employee.getEmployee_LastName()+"!!!");
		Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println();
			System.out.println("----------------------------------------------");
			try {
			Thread.sleep(50);
			System.out.println("  ++++++++++++++++++++++++++++++++++");
			Thread.sleep(50);
			System.out.println("                Choose option");
			Thread.sleep(50);
			System.out.println(" ++++++++++++++++++++++++++++++++++++");
			Thread.sleep(50);
			System.out.println("1. View Profile      2. Update Profile");
			Thread.sleep(50);
			System.out.println("3. Change Password   4. Apply for Leave");
			Thread.sleep(50);
			System.out.println("5. View Leave Status    6.Exit");
			Thread.sleep(50);
			System.out.println("----------------------------------------------");
			} catch (InterruptedException e) {}
			
			int ch=sc.nextInt();
			
			switch(ch) {
			case 1:
				EmployeeCase.printSingleEmployee(employee);
				break;
			case 2:
				UpdateEmployee.main(employee.getEmployeeId());
				break;
			case 3:
				ChangeEmployeePassWord.main(employee.getEmployeeId());
				break;
			case 4:
				ApplyLeave.main(employee.getEmployeeId());
				break;
			case 5:
				System.out.println("Enter your Id");
				int id=sc.nextInt();
				ViewLeaveStatus.main(id);
				break;
			case 6:
				SpecialFeatures.thankYou();
				return;
				default:
					System.out.println("Wrong Input");
			}
			
		}
		
		
	}
	
	
	
	}


