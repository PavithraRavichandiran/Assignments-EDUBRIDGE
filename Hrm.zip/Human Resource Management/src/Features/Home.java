package Features;

import java.util.Scanner;

import model.Employee;

public class Home {
	public  static void option() throws Exception {
	Scanner scanner =new  Scanner(System.in);
	Login login=new Login();
	while(true) {
		System.out.println(" 1.Admin login \n 2.Employee login  \n 3.Exit");
		System.out.println("Enter your choice");
		int choice =scanner.nextInt();
		switch(choice) {
		case 1:
			if(login.adminLoginAuthentication()) {
				Options.adminPanel();
				
			}
			else {
				System.out.println("Wrong credentials");
			}
			break;
		case 2:
			Employee employee=login.employeeLoginAuthentication();
			Options.employeePanel(employee);
		
			break;
		case 3:
			System.out.println("See you ,,Bye....");
			System.exit(0);
		}
	}

}
}
