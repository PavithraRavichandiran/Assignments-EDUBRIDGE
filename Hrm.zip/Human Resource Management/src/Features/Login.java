package Features;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

import exceptions.EmployeeException;
import jdbcconnection.Connect;

import java.sql.ResultSet;
import java.sql.SQLException;

import model.Address;
import model.Employee;

public class Login {
	PreparedStatement preparedStatement = null;
	Connection connection = null;

	public Login() {
		connection = Connect.getMyConnection();
	}

	public boolean adminLoginAuthentication() {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Admin Name");
		String adminName = scanner.next();
		System.out.println("Enter the Password");
		String passWord = scanner.next();
		SpecialFeatures.loading();
		if (adminName.equals("Pavithra") && passWord.equals("pavi*192")) {
			return true;
		}

		return false;
	}

	public Employee employeeLoginAuthentication() throws EmployeeException, SQLException {
		// TODO Auto-generated method stubS
		Employee employee = null;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the employee email id");
		String emailId = scanner.next();
		System.out.println("Enter the Password");
		String passWord = scanner.next();
		SpecialFeatures.loading();

		try {
			preparedStatement = connection.prepareStatement("select*from employee where emailId=?");
			preparedStatement.setString(1, emailId);
			ResultSet resultSet;
			
				resultSet = preparedStatement.executeQuery();
				if (resultSet.next()) {
					employee = new Employee();
					employee.setEmployeeId(resultSet.getInt("Id"));
					employee.setEmployeePassword(resultSet.getString("Password"));
					employee.setEmployee_firstName(resultSet.getString("FirstName"));
					employee.setEmployee_LastName(resultSet.getString("LastName"));
					employee.setEmployee_DateOfBirth(resultSet.getString("DateOfBirth"));
					employee.setEmployee_ContactNo(resultSet.getString("ContactNo"));
					employee.setEmployee_EmailID(resultSet.getString("EmailId"));
					employee.setEmployeePermanentAddress(resultSet.getString("PermanentAddress"));
					employee.setEmployeeCurrentAddress(resultSet.getString("CurrentAddress"));
					employee.setEmployee_DateOfJoining(resultSet.getString("DateOfJoining"));
					employee.setEmployeeDepartment(resultSet.getInt("DepartmentId"));
					employee.setEmployeeSalary(resultSet.getDouble("Salary"));
					employee.setEmployee_DateOfExit(resultSet.getString("DateOfExit"));
					
					
					if (!employee.getEmployeePassword().equals(passWord)) {
						throw new EmployeeException("Wrong Password");
					}
				}
				else
				{
					throw new EmployeeException("Email Id does not exist");
				}
				
				
			} catch (EmployeeException e) {
				throw new EmployeeException(e.getMessage());
				
			}
		
			
		return employee;
	}

}
