package main;

import java.util.List;


import model.Employee;

public class EmployeeCase {
public static void printEmployeeList(List<Employee>list){
		
	/*
	 * int fnl=10,lnl=10,eml=0,psl=0,adl=0,pdl=0; for(int i=0; i<list.size(); i++) {
	 * Employee e=list.get(i); fnl=Math.max(fnl,
	 * e.getEmployee_firstName().length()); lnl=Math.max(lnl,
	 * e.getEmployee_LastName().length()); eml=Math.max(eml,
	 * e.getEmployee_EmailID().length()); psl=Math.max(psl,
	 * e.getEmployeePassword().length()); adl=Math.max(adl, ((CharSequence)
	 * e.getEmployeePermanentAddress()).length()); pdl=Math.max(pdl, ((CharSequence)
	 * e.getEmployeeCurrentAddress()).length()); }
	 * 
	 * System.out.println(); System.out.println(
	 * "-------------------------------------------------------------------------------")
	 */; 
		
		for(Employee employee: list){ 
			 
			int empId=employee.getEmployeeId();
			String passWord=employee.getEmployeePassword();
			String firstName=employee.getEmployee_firstName();
			String lastName=employee.getEmployee_LastName();
			String dateOfbirth=employee.getEmployee_DateOfBirth();
			String contactNo=employee.getEmployee_ContactNo();
			String emailId=employee.getEmployee_EmailID();
			String permanentAddress=employee.getEmployeePermanentAddress();
		String currentAddress=employee.getEmployeeCurrentAddress();
			String dateOfJoining=employee.getEmployee_DateOfJoining();
			int departmentId=employee.getEmployeeDepartment();
			double salary=employee.getEmployeeSalary();
			String dateOfExit=employee.getEmployee_DateOfExit();
			try {
		System.out.println("Employee Id: "+empId);
		Thread.sleep(20);
		System.out.println("Employee Password:"+passWord);
		Thread.sleep(20);
		System.out.println("Employee Firstname:"+firstName);
		Thread.sleep(20);
		System.out.println("Employee LastName:"+ lastName);
		Thread.sleep(20);
		System.out.println("Employee Date of Birth: "+dateOfbirth);
		Thread.sleep(20);
		System.out.println("Employee ContactNO:" +contactNo);
		Thread.sleep(20);
		System.out.println("Employee EmailId:" +emailId);
		Thread.sleep(20);
		System.out.println("Employee Permanent Address:"  +permanentAddress);
		Thread.sleep(20);
		System.out.println("Employee Current Address:" + currentAddress);
		Thread.sleep(20);
		System.out.println("Employee Date of Joining:" +dateOfJoining);
		Thread.sleep(20);
		System.out.println("Department ID:" +departmentId);
		Thread.sleep(20);
		System.out.println("Employee Salary:" +salary);
		Thread.sleep(20);
		System.out.println("Employee Date of Exit:"+dateOfExit);
		Thread.sleep(20);
		System.out.println("-----------------------------------------------------------");
		Thread.sleep(20);
			} catch (InterruptedException e1){}
		} 
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e1) {}
		 
	}
	
	
	
	
	
	public static void printSingleEmployee(Employee e) {
		System.out.println();

		try {
		System.out.println( "============================================");
		Thread.sleep(20);
		System.out.println("");
		Thread.sleep(20);
		System.out.println("Employee Id: "+e.getEmployeeId());
		Thread.sleep(20);
		System.out.println("Employee Password:"+e.getEmployeePassword());
		Thread.sleep(20);
		System.out.println("Employee Firstname:"+e.getEmployee_firstName());
		Thread.sleep(20);
		System.out.println("Employee LastName:"+ e.getEmployee_LastName());
		Thread.sleep(20);
		System.out.println("Employee Date of Birth: "+e.getEmployee_DateOfBirth());
		Thread.sleep(20);
		System.out.println("Employee ContactNO:" +e.getEmployee_ContactNo());
		Thread.sleep(20);
		System.out.println("Employee EmailId:" +e.getEmployee_EmailID());
		Thread.sleep(20);
		System.out.println("Employee Permanent Address:"  +e.getEmployeePermanentAddress());
		Thread.sleep(20);
		System.out.println("Employee Current Address:" + e.getEmployeeCurrentAddress());
		Thread.sleep(20);
		System.out.println("Employee Date of Joining:" +e.getEmployee_DateOfJoining());
		Thread.sleep(20);
		System.out.println("Department ID:" +e.getEmployeeDepartment());
		Thread.sleep(20);
		System.out.println("Employee Salary:" +e.getEmployeeSalary());
		Thread.sleep(20);
		System.out.println("Employee Date of Exit:"+e.getEmployee_DateOfExit());
		
		System.out.println(" ");
		Thread.sleep(20);
		System.out.println("=========================================");
		Thread.sleep(20);
		} catch (InterruptedException e1) {}
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e1) {}
	}

}



