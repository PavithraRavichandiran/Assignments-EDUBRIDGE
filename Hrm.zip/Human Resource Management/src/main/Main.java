package main;

import Features.Home;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	Home.option();
} catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	}

}
