package cases;

import java.util.Scanner;

import dao.EmployeeInterface;
import dao.EmployeeInterfaceImpl;

public class TransferEmployee {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter employee id");
		int empId=scanner.nextInt();
		System.out.println("Enter department name");
		int depId=scanner.nextInt();
		EmployeeInterface employeeInterface = new EmployeeInterfaceImpl();
		 String result=employeeInterface.changeDepartment(empId, depId);
		 System.out.println(result);
		
	}

}
