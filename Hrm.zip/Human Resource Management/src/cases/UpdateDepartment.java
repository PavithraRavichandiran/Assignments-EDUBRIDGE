package cases;

import java.util.Scanner;

import dao.DepartmentInterface;
import dao.DepartmentInterfaceImpl;
import model.Department;

public class UpdateDepartment {
	public static void main(String[] args) {
		Scanner scanner =new Scanner (System.in);
		System.out.println("Enter the department id");
		int id=scanner.nextInt();
		System.out.println("Enter the department name");
          String name=scanner.next()	;

DepartmentInterface departmentInterface=new DepartmentInterfaceImpl();
String result= departmentInterface.updateDepartment(new Department(id,name));
System.out.println(result);
	}

}
