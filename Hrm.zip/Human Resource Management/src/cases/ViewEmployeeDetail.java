package cases;

import dao.EmployeeInterface;
import dao.EmployeeInterfaceImpl;
import exceptions.EmployeeException;
import main.EmployeeCase;
import model.Employee;

public class ViewEmployeeDetail {
public static void main(int id) {
		
		EmployeeInterface employeeInterface=new EmployeeInterfaceImpl();
		
		try {
			Employee result=employeeInterface.getEmployeeById(id);
			EmployeeCase.printSingleEmployee(result);
		} catch (EmployeeException e) {
			System.out.println(e.getMessage());
		}
}
}
