package cases;

import java.util.List;
import java.util.ListIterator;

import dao.EmployeeInterface;
import dao.EmployeeInterfaceImpl;
import exceptions.EmployeeException;
import main.EmployeeCase;
import model.Employee;

public class ViewAllEmployee {
public static void main(String[] args) {
		
		EmployeeInterface employee=new EmployeeInterfaceImpl();
		
		try {
			List<Employee>list=employee.getAllEmployee();
			EmployeeCase.printEmployeeList(list);
			}
		 catch (EmployeeException e) {
			System.out.println(e.getMessage());
		}

	}


}
