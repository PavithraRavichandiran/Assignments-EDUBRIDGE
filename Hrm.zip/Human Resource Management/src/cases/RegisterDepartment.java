package cases;

import java.sql.SQLException;
import java.util.Scanner;

import dao.DepartmentInterface;
import dao.DepartmentInterfaceImpl;

public class RegisterDepartment {
	public static void main(String[] args) throws SQLException {
		
	
	DepartmentInterface departmentInterface=new DepartmentInterfaceImpl();
	Scanner scanner =new Scanner(System.in);
	
	System.out.println("Enter the department name");
	String name=scanner.next();
	 System.out.println(departmentInterface.registerDepartment( name));
	}
	

}
