package cases;

import dao.LeaveInterface;
import dao.LeaveInterfaceImpl;

public class RejectLeave {
	public static void  main(int id) {
		LeaveInterface leaveInterface= new LeaveInterfaceImpl();
		String result=leaveInterface.rejectLeave(id);
		System.out.println(result);
	}
	

}
