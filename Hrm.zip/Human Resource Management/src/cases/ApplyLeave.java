package cases;

import java.util.Scanner;

import dao.LeaveInterface;
import dao.LeaveInterfaceImpl;

public class ApplyLeave {
	public static void main(int id) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the leave from date");
		String fromDate=scanner.next();
		System.out.println("Enter the leave Todate");
		String ToDate=scanner.next();
		LeaveInterface leaveInterface=new LeaveInterfaceImpl();
		String result=leaveInterface.requestLeave(id, fromDate, ToDate);
		System.out.println(result);
	}
}
