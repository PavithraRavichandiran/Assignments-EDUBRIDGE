package cases;

import java.util.Scanner;

import dao.EmployeeInterface;
import dao.EmployeeInterfaceImpl;
import model.Employee;

public class RegisterEmployee {
	public static void main(String[] args) {
		String eId=null;
		String emailId=null;
		int len =0;
		String num=null,contactNo=null;
	
		EmployeeInterface employeeInterface=new EmployeeInterfaceImpl();
	
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter the  FirstName");
		String firstName=scanner.next();
		System.out.println("Enter the  LastName");
		String lastName=scanner.next();
		System.out.println("Enter the  Date of birth");
		String dateOfBirth=scanner.next();
		do {
		System.out.println("Enter the ContactNo");
		 num=scanner.next();
		len = num.length();
		if (len == 10) {
			contactNo = num;
		} else {
			System.out.println("enter 10 digit number");
			
			if (len == 10) {
				contactNo = num;
			}

		}
	} while ((len) != 10);
		do {
		System.out.println("Enter Email Id");
		emailId=scanner.next();
		if(employeeInterface.isValid(emailId))
			eId=emailId;
		else {
			System.out.println(("enter valid Emaild:"));
			emailId= scanner.next();
			if (employeeInterface.isValid(emailId)) {
				eId= emailId;
			}
		}
		}while(!employeeInterface.isValid(emailId));
		System.out.println("Enter permanent address in detail as mentioned below");
		System.out.println("Buliding Number,Area ,City,State,Country");
		String permanentAddress=scanner.next();
		System.out.println("Enter current address in detail as mentioned below");
		System.out.println("Buliding Number,Area ,City,State,Country");
		String currentAddress=scanner.next();
		System.out.println("Enter DateofJoining");
		String dateOfJoining=scanner.next();
		System.out.println("Enter department Id");
		int department=scanner.nextInt();
		System.out.println("Enter salary");
		double salary=scanner .nextDouble();
		System.out.println("Enter date of exit,if New Joiner & working say,NA");
		String dateOfExit=scanner.next();
		System.out.println("Enter the  password");
		String password=scanner.next();
		
		 
		
		String pass;
		for(int i=0;i<contactNo.length();i++) {
			password+=contactNo.charAt(i);
			if(i==3)
				break;
		}
		String result= employeeInterface .registerEmployee(new Employee(password,firstName,lastName,dateOfBirth,
				contactNo,emailId,permanentAddress,currentAddress,dateOfJoining,department,salary,dateOfExit));
	System.out.println(result);
				
	}

}
