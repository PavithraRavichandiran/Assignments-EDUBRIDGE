package cases;

import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

import dao.EmployeeInterface;
import dao.EmployeeInterfaceImpl;
import exceptions.EmployeeException;
import model.Employee;

public class EmployeeByDepartment {
	public static void main(String []args) {
		Scanner scanner =new Scanner(System.in);
		System.out.println("Enter the department Id");
		int id=scanner.nextInt();
		
		EmployeeInterface employeeInterface = new EmployeeInterfaceImpl();
		 List<Employee> list;
		try {
			list = employeeInterface.getEmployeeByDepartment(id);
			ListIterator listIterator= list.listIterator();
			for (Employee employee : list) {
				System.out.println(employee);
			}
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
			
		}
	}


