package cases;

import dao.LeaveInterface;
import dao.LeaveInterfaceImpl;

public class ViewLeaveStatus {
	public static void main(int id) {
		LeaveInterface leaveInterface=new LeaveInterfaceImpl();
	String result=	leaveInterface.approveLeave(id);
		System.out.println(result);
	}
}
