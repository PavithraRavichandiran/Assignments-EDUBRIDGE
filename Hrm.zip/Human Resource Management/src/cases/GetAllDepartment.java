/**
 * 
 */
package cases;

import java.util.List;
import java.util.ListIterator;

import dao.DepartmentInterface;
import dao.DepartmentInterfaceImpl;
import exceptions.DepartmentException;
import model.Department;

/**
 * @author admin
 *
 */
public class GetAllDepartment {
	public static void main(String[] args) throws DepartmentException {
		DepartmentInterface departmentInterface=new DepartmentInterfaceImpl();
	
		 List<Department> list=departmentInterface.getAllDepartment();
		 ListIterator listIterator=list.listIterator();
		 for (Department department : list) {
			 System.out.println(department);
			
		}
		 
		 
		
	}

}
