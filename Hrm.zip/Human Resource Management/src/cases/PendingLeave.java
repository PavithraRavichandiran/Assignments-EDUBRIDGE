package cases;

import java.util.List;
import java.util.Scanner;

import dao.LeaveInterface;
import dao.LeaveInterfaceImpl;
import model.Leave;

public class PendingLeave {
	public static void main(String[] args) {
		
	
	LeaveInterface leaveInterface=new LeaveInterfaceImpl();
	List<Leave>list=leaveInterface.pendingLeaves();
	
	if(list.size()==0) {
		System.out.println("No Leave Request");
		return;
	}
	
	System.out.println(list);
	
	
	
	Scanner scanner=new Scanner(System.in);
	while(true) {
		System.out.println("1. Approve leave");
		System.out.println("2. Reject leave");
		System.out.println("3. Go Back");
		int ch=scanner.nextInt();
		
		switch(ch) {
		case 1:
			System.out.println("Enter ID of Employee");
			int id1=scanner.nextInt();
			ApproveLeave.main(id1);
			break;
		case 2:
			System.out.println("Enter ID of Employee");
			int id2=scanner.nextInt();
			RejectLeave.main(id2);
			break;
		case 3:
			return;
		default :
			System.out.println("Wrong Input");
		}
	}
}

}
