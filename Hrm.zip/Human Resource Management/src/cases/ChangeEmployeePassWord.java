package cases;

import java.sql.SQLException;
import java.util.Scanner;

import dao.EmployeeInterface;
import dao.EmployeeInterfaceImpl;

public class ChangeEmployeePassWord {
	public static void main(int id)  {

		EmployeeInterface employeeInterface = new EmployeeInterfaceImpl();

		String result;
		try {
			result = employeeInterface.changeEmployeePassword(id);
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
	}

}
