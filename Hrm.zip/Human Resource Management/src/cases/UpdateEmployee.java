package cases;

import java.util.Scanner;

import dao.EmployeeInterface;
import dao.EmployeeInterfaceImpl;

public class UpdateEmployee {
	public static void main(int id) {

		try {
		System.out.println();
		System.out.println("==============================================");
		Thread.sleep(50);
		System.out.println("        Select update");
		Thread.sleep(50);
		System.out.println("==============================================");
		Thread.sleep(50);
		System.out.println("1. First Name      2. Last Name");
		Thread.sleep(50);
		System.out.println("3. Mobile          4. Email");
		Thread.sleep(50);
		System.out.println("5. DOB             6.Permanent Address");
		Thread.sleep(50);
		System.out.println("7. Currrent Address            8.Date of Joining");
		Thread.sleep(50);
		System.out.println("9.Department Name        10. Salary");
		Thread.sleep(50);
		System.out.println("11.Password        12.Date of Exit   13.Exit");
		} catch (InterruptedException e1) {}
		
		
		Scanner scanner=new Scanner(System.in);
		int choice=13;
		
		try {
			choice=scanner.nextInt();
		} catch (Exception e) {}
		
		String column="";
		String value="";
		
		switch(choice) {
		case 1:
			System.out.println("Enter Employee New First Name");
			column="FirstName";
			value=scanner.next();
			break;
			
		case 2:
			System.out.println("Enter Employee New Last Name");
			column="LastName";
			value=scanner.next();
			break;
			
		case 3:
			System.out.println("Enter Employee New Mobile");
			column="ContactNo";
			value=scanner.next();
			break;
		case 4:
			System.out.println("Enter Employee New Email");
			column="EmailId";
			value=scanner.next();
			break;
		case 5:
			System.out.println("Enter Employee New DOB");
			column="DateOfBirth";
			value=scanner.next();
			break;
		case 6:
			System.out.println("Enter Employee  New Permanent Address");
			column="PermanentAddress";
		     value=scanner.next();
			break;
		case 7:
			System.out.println("Enter Employee New Current Address");
			column="CurrentAddress";
			value=scanner.next();
			break;
		case 8:
			System.out.println("Enter Employee Date of Joining");
			column="DateOfJoining";
			value=scanner.next();
			break;
		case 9:
			
			System.out.println("Enter Employee New DepartmentID");
			column="DepartmentId";
			value=scanner.next();
			break;
		case 10:
			System.out.println("Enter Employee New Salary");
			column="Salary";
			value=scanner.next();
			break;
		case 11:
			System.out.println("Enter Employee New Password");
			column="Password";
			value=scanner.next();
		break;
		case 12:
			System.out.println("Enter Date of Exit ");
			column="DateOfExit";
			value=scanner.next();
			
		default :
			
			return;

		}
		
		EmployeeInterface employeeInterface=new EmployeeInterfaceImpl();
		
		String result=employeeInterface.updateEmployee(column, value, id);
		
		System.out.println(result);
		


}
}
