package dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import javax.xml.transform.Result;

import exceptions.EmployeeException;
import jdbcconnection.Connect;
import model.Address;
import model.Employee;

public class EmployeeInterfaceImpl implements EmployeeInterface{
	Connection connection = null;
	PreparedStatement preparedStatement = null;
	public EmployeeInterfaceImpl() {
		connection=Connect.getMyConnection();
	}

	
	@Override
	public String registerEmployee(Employee employee) {
		String message = "Employee not registered";
		
		try {

			preparedStatement = connection.prepareStatement("insert into employee (FirstName,LastName,DateOfBirth,ContactNo,EmailId,PermanentAddress,CurrentAddress,DateOfJoining,DepartmentId,Salary,DateOfExit,Password)values(?,?,?,?,?,?,?,?,?,?,?,?)");
			
			preparedStatement.setString(1, employee.getEmployee_firstName());
			preparedStatement.setString(2, employee.getEmployee_LastName());
			preparedStatement.setString(3, employee.getEmployee_DateOfBirth());
			preparedStatement.setString(4, employee.getEmployee_ContactNo());
			preparedStatement.setString(5, employee.getEmployee_EmailID());
			preparedStatement.setString(6, employee.getEmployeePermanentAddress());
			preparedStatement.setString(7, employee.getEmployeeCurrentAddress());
			preparedStatement.setString(8, employee.getEmployee_DateOfJoining());
			preparedStatement.setInt(9, employee.getEmployeeDepartment());
			preparedStatement.setDouble(10, employee.getEmployeeSalary());
			preparedStatement.setString(11, employee.getEmployee_DateOfExit());
			preparedStatement.setString(12, employee.getEmployeePassword());
			int result = preparedStatement.executeUpdate();
			if (result > 0) 
				message="Employee registered Successfully !  Password is "+employee.getEmployeePassword();
			

		} catch (SQLException e) {
			message=e.getMessage();
		}

		
		return message;
	}

	@Override
	public String changeDepartment(int employeeId,int  departmentId) {
		String message = "Department not changed!";

		// TODO Auto-generated method stub
		try {
			preparedStatement = connection
					.prepareStatement("update  employee set DepartmentId=? where Id=? ");
			preparedStatement.setInt(1, departmentId);
			preparedStatement.setInt(2, employeeId);
			int result = preparedStatement.executeUpdate();
			if (result > 0) {

				message="Employee transfered to new department!";
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			 e.printStackTrace();
		}
		return message;
	}

	@Override
	public String changeEmployeePassword(int employeeId) throws SQLException {
		String message = "changed";
		// TODO Auto-generated method stub
		preparedStatement = connection.prepareStatement("select * from employee where Id=?");
		preparedStatement.setInt(1, employeeId);
		ResultSet resultSet = preparedStatement.executeQuery();
		if (resultSet.next()) {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter your old password");
			String password = scanner.next();
			if (password.equals(resultSet.getString("Password"))) {
				message = changePassword(employeeId);
			} else {
				System.out.println("IncorrectPassword");
			}
		} else {
			return "cannot find employee";
		}

		return message;
	}

	private String changePassword(int empId) {
		String message = "Password not updated";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your new password");
		String newPassword = sc.next();
		try {
			preparedStatement = connection
					.prepareStatement("update employee set Password=? where Id=?");
			preparedStatement.setString(1, newPassword);
			preparedStatement.setInt(2, empId);
			int result = preparedStatement.executeUpdate();
			if (result > 0) {
				message="Password updated successfully";
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			message = e.getMessage();
		}
		return message;
	}

	@Override
	public Employee getEmployeeById(int employeeId) throws EmployeeException {
		Employee employee = null;
		// TODO Auto-generated method stub
		try {
			preparedStatement = connection.prepareStatement("select*from employee where Id=?");
			preparedStatement.setInt(1, employeeId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				int id = resultSet.getInt("Id");
				String password = resultSet.getString("Password");
				String firstName = resultSet.getString("FirstName");
				String lastName = resultSet.getString("LastName");
				String dateOfBirth = resultSet.getString("DateOfBirth");
				String contactNo = resultSet.getString("ContactNo");
				String emailId = resultSet.getString("EmailId");
				String permanentAddress =  resultSet.getString("PermanentAddress");
				String currentAddress =  resultSet.getString("CurrentAddress");
				String dateOfJoining = resultSet.getString("DateOfJoining");
				int department = resultSet.getInt("DepartmentId");
				Double salary = resultSet.getDouble("Salary");
				String dateOfExit = resultSet.getString("DateOfExit");
			employee=	new Employee(id, password, firstName, lastName, dateOfBirth, contactNo, emailId, permanentAddress,
						currentAddress, dateOfJoining, department, salary, dateOfExit);

			} 
		else{
				throw new EmployeeException("Employee does not exist with this id:" + employeeId);
			}
		}catch(SQLException e) {
				throw new EmployeeException(e.getMessage());
			}

		return employee;
	}

	@Override
	public List<Employee> getEmployeeByDepartment(int departmentId) throws EmployeeException {
		List<Employee>list=new ArrayList<>();
		try {
			
		preparedStatement=connection.prepareStatement("select*from employee where DepartmentId=?");
		preparedStatement.setInt(1,departmentId);
		ResultSet resultSet=preparedStatement.executeQuery();
		while(resultSet.next()) {
			Employee employee=new Employee();
			employee.setEmployeeId(resultSet.getInt("Id"));
			employee.setEmployeePassword(resultSet.getString("Password"));
			employee.setEmployee_firstName(resultSet.getString("FirstName"));
			employee.setEmployee_LastName(resultSet.getString("LastName"));
			employee.setEmployee_DateOfBirth(resultSet.getString("DateOfBirth"));
			employee.setEmployee_ContactNo(resultSet.getString("ContactNo"));
			employee.setEmployee_EmailID(resultSet.getString("EmailId"));
			employee.setEmployeePermanentAddress(resultSet.getString("PermanentAddress"));
			employee.setEmployeeCurrentAddress(resultSet.getString("CurrentAddress"));
			employee.setEmployee_DateOfJoining(resultSet.getString("DateOfJoining"));
			employee.setEmployeeDepartment(resultSet.getInt("DepartmentId"));
			employee.setEmployeeSalary(resultSet.getDouble("Salary"));
			employee.setEmployee_DateOfExit(resultSet.getString("DateOfExit"));
			

			
			 list.add(employee);
			
			 
			 
			
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
		if(list.size()==0) {
			System.out.println(" No employee in this department..");
		}
		
		return list;
	}

	@Override
	public List<Employee> getAllEmployee() throws EmployeeException {
		List<Employee>list=new ArrayList<>();
		try {
			
		preparedStatement=connection.prepareStatement("select*from employee");
		ResultSet resultSet=preparedStatement.executeQuery();
		while(resultSet.next()) {
			Employee employee=new Employee();
			employee.setEmployeeId(resultSet.getInt("Id"));
			employee.setEmployeePassword(resultSet.getString("Password"));
			employee.setEmployee_firstName(resultSet.getString("FirstName"));
			employee.setEmployee_LastName(resultSet.getString("LastName"));
			employee.setEmployee_DateOfBirth(resultSet.getString("DateOfBirth"));
			employee.setEmployee_ContactNo(resultSet.getString("ContactNo"));
			employee.setEmployee_EmailID(resultSet.getString("EmailId"));
			employee.setEmployeePermanentAddress(resultSet.getString("PermanentAddress"));
			employee.setEmployeeCurrentAddress(resultSet.getString("CurrentAddress"));
			employee.setEmployee_DateOfJoining(resultSet.getString("DateOfJoining"));
			employee.setEmployeeDepartment(resultSet.getInt("DepartmentId"));
			employee.setEmployeeSalary(resultSet.getDouble("Salary"));
			employee.setEmployee_DateOfExit(resultSet.getString("DateOfExit"));
			

			
			 list.add(employee);
			 
			
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException(e.getMessage());
		}
		if(list.size()==0) {
			throw new EmployeeException("No Records found");
		}
		
		return list;
	}

	@Override
	public String updateEmployee( String column ,String typeName,int employeeId) {
		
		// TODO Auto-generated method stub
		String message="Not updated!";
		try {
			preparedStatement =connection.prepareStatement("update  employee  set "+column+"=? where Id=?" );
		preparedStatement.setString(1,typeName);
		preparedStatement.setInt(2, employeeId);
		int result=preparedStatement.executeUpdate();
		if(result>0) {
			message=column +"  "+"Updated Successfully";
		}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			 message=e.getMessage();
		}
		return message;
	}


	@Override
	public boolean isValid(String emailId) {
		// TODO Auto-generated method stub
		String regex = "^(.+)@(.+)$";     
        Pattern pat = Pattern.compile(regex);
        if (emailId == null||emailId.length()==0)
            return false;
        return pat.matcher(emailId).matches();
		
	}

	
}
