package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import exceptions.DepartmentException;
import jdbcconnection.Connect;
import model.Department;

public class DepartmentInterfaceImpl implements DepartmentInterface {
	Connection connection=null;
	PreparedStatement preparedStatement=null;
	public DepartmentInterfaceImpl(){
		
		connection=Connect.getMyConnection();
	}
	

	@Override
	public String registerDepartment( String departmentName) {
	
		String message="Department not added!";
		try {
		preparedStatement=connection.prepareStatement("insert into department( departmentName) values(?)");
		
		preparedStatement.setString(1, departmentName);
	
		int result=preparedStatement.executeUpdate();
		if(result>0) {
	message="Department added";
		}
		}catch(SQLException e) {
			message=e.getMessage();
		}
			
		return message;
		}
	

	@Override
	public List<Department> getAllDepartment() throws DepartmentException {
		// TODO Auto-generated me
		List <Department>list=new ArrayList<>();
		try {
			preparedStatement= connection.prepareStatement("select*from department");
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()) {
				int id=resultSet.getInt("id");
				String name=resultSet.getString("departmentName");
				Department department=new Department(id,name);
				list.add(department);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new DepartmentException(e.getMessage());
		}
		if(list.size()==0) {
			throw new DepartmentException("DepartmentNotFouund");
		}
		return list;
	}

	@Override
	public String updateDepartment(Department department) {
		// TODO Auto-generated method stub
		String message="Department updated";
		try {
			preparedStatement=connection.prepareStatement("update department set departmentName=? where id=?");
			preparedStatement.setString(1,department.getName());
			preparedStatement.setInt(2,department.getId());
			int result=preparedStatement.executeUpdate();
			if(result>0) {
				System.out.println("updated successfully!!");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			 message=e.getMessage();
		}
		
			
			return message;
		
	}

}
