package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jdbcconnection.Connect;
import model.Leave;

public class LeaveInterfaceImpl  implements LeaveInterface{
	PreparedStatement preparedStatement=null;
	Connection connection=null;
	 public LeaveInterfaceImpl() {
		 connection=Connect.getMyConnection();
	 }

	@Override
	public String requestLeave(int employeeId, String startDate, String endDate) {
		// TODO Auto-generated method stub
		String  message="Not Applied";
		try {
			
			preparedStatement=connection.prepareStatement("insert into leaves(employeeId,FromDate,ToDate)values(?,?,?)");
		preparedStatement.setInt(1, employeeId);
		preparedStatement.setString(2, startDate);
		preparedStatement.setString(3, endDate);
		int result=preparedStatement.executeUpdate();
		if(result>0) {
			message="Applied Successfully";
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			message=e.getMessage();
		} 
		return message;
	}

	@Override
	public String approveLeave(int employeeId) {
		// TODO Auto-generated method stub
		String message="Not Approved";
		try {
			
			preparedStatement =connection.prepareStatement("update  leaves set status='Approved' where EmployeeId=?");
		preparedStatement.setInt(1, employeeId);
		int result=preparedStatement.executeUpdate();
		if(result>0) {
			message="Leave Approved";
			
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			 message=e.getMessage();
		}
		return message;
	}

	@Override
	public String rejectLeave(int employeeID) {
		// TODO Auto-generated method stub
		String message="Not Rejected";
		try {
			
			preparedStatement =connection.prepareStatement("update  leaves set status='Rejected' where employeeId=?");
		preparedStatement.setInt(1, employeeID);
		int result=preparedStatement.executeUpdate();
		if(result>0) {
			message="Leave Rejected";
			
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			 message=e.getMessage();
		}
		return message;
	}

	@Override
	public List<Leave> pendingLeaves() {
		// TODO Auto-generated method stub
		List<Leave> list=new ArrayList<>();
		try {
			preparedStatement=connection.prepareStatement("select l.EmployeeId,l.status,e.FirstName,e.LastName,l.FromDate,l.ToDate,e.DepartmentId from leaves l inner join  employee e ON e.Id = l.EmployeeId and l.status='pending'");
		ResultSet resultSet=preparedStatement.executeQuery();
		while(resultSet.next()) {
			 Leave leave =new Leave();
			 leave.setEmployeeId(resultSet.getInt("employeeId"));
			 leave.setStatus(resultSet.getString("status"));
			 leave.setEmployee_firstName(resultSet.getString("FirstName"));
			 leave.setEmployee_LastName(resultSet.getString("LastName"));
			 leave.setStartDate(resultSet.getString("FromDate"));
			 leave.setEndDate(resultSet.getString("ToDate"));
			 leave.setDepartmentId(resultSet.getInt("departmentId"));
			 list.add(leave);
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Leave viewMyLeaveStatus(int employeeid) {
		Leave leave=null;
		// TODO Auto-generated method stub
		try {
			preparedStatement=connection.prepareStatement("select status from leaves where EmployeeId=?");
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()) {
				String status=resultSet.getString("status");
				leave=new Leave(status);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return leave;
	}

}
