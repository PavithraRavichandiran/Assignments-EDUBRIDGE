package dao;

import java.sql.SQLException;
import java.util.List;

import exceptions.EmployeeException;
import model.Employee;

public interface EmployeeInterface {
	public String registerEmployee(Employee employee);

	public String changeDepartment(int employeeID, int depid);

	public String changeEmployeePassword(int employeeId) throws SQLException;

	public Employee getEmployeeById(int employeeId) throws EmployeeException;

	public List<Employee> getEmployeeByDepartment(int departmentId) throws EmployeeException;

	public List<Employee> getAllEmployee() throws EmployeeException;

	public String updateEmployee(String column, String typeName, int employeeId);

	public boolean isValid(String emailId);

}
