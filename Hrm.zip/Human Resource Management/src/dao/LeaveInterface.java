package dao;

import java.util.List;

import model.Leave;

public interface LeaveInterface {
	public String requestLeave(int employeeId,String startDate,String endDate);
	public String approveLeave(int employeeId);
	public String rejectLeave(int employeeID);
	public List<Leave>pendingLeaves();
	public Leave viewMyLeaveStatus(int employeeid);
	
}
