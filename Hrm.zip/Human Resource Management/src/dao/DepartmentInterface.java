package dao;

import java.sql.SQLException;
import java.util.List;

import exceptions.DepartmentException;
import model.Department;

public interface DepartmentInterface {
	
public String registerDepartment( String departmentName) throws SQLException;
public List<Department>getAllDepartment() throws DepartmentException;
public String updateDepartment(Department department);
}
