package jdbcconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connect {

	
	
	  
	 
	
	  public static Connection getMyConnection() {
		  Connection  connection=null;
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/HumanResourceManagement", "root", "paviSQL123");
			} catch(SQLException ex)
			{
				System.out.println(ex.getMessage());
				
			}catch(Exception e)
			{
				System.out.println(e.getMessage());
				
			}
			return connection;

     


		
	
	  }
}

