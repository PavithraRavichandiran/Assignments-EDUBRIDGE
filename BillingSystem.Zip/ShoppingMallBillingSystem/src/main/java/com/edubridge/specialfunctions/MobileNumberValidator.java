package com.edubridge.specialfunctions;
/*
 * package com.edubridge.SpecialFunctions;
 * 
 * import java.lang.annotation.Retention; import java.lang.annotation.Target;
 * 
 * import javax.validation.Constraint; import javax.validation.Payload;
 * 
 * @Target({ElementType.FIELD , ElementType.METHOD})
 * 
 * @Retention(RetentionPolicy.RUNTIME)
 * 
 * @Constraint(validatedBy = MobileNumberValidation.class)
 * 
 * public @interface MobileNumberValidator { String message() default
 * "Enter  valid 10 digits mobile number";
 * 
 * Class<?>[] groups() default {} ;
 * 
 * Class<? extends Payload>[] payload() default {} ; }
 */
