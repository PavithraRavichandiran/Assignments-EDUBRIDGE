
  package com.edubridge.service;
  
  public interface BillService {
	  public double totalPrice(double price,int quantity);
	  
	  public float tax(); public double invoiceTotal(); }
 