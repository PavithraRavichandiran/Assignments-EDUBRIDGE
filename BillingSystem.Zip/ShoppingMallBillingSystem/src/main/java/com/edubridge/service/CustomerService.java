/*
 * package com.edubridge.service;
 * 
 * import java.util.Optional;
 * 
 * import com.edubridge.entity.Customer;
 * 
 * public interface CustomerService { public Customer saveCustomer(Customer
 * customer); public Customer getCustomerByContactNumber(String ContactNumber);
 * 
 * 
 * }
 */