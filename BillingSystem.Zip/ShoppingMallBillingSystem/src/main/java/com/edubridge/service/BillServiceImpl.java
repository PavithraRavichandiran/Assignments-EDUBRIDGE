
  package com.edubridge.service;
  
  public class BillServiceImpl implements BillService {
  
  double totalPrice;int tax;double invoiceTotal;
  
  @Override 
  public double totalPrice(double price, int quantity) {
  totalPrice=quantity*price; return quantity*price;
  }
  public float tax() {
	  if(totalPrice<1000) 
		  return tax=(int) totalPrice; 
	  if(totalPrice>=1000 && totalPrice<1500)
		  return tax=(int) (totalPrice*(2.5/100));
	  if(totalPrice>=1500 && totalPrice<2500) 
		  return tax=(int) (totalPrice*(6/100));
  if(totalPrice>=1500 && totalPrice<4500) 
	  return tax=(int) (totalPrice*(6/100));
  if(totalPrice>=4500) 
	  return tax=(int) (totalPrice*(18/100)); 
  return 0;
  
  
  }
  
  @Override public double invoiceTotal() { // TODO Auto-generated method stub
  invoiceTotal=totalPrice+tax;
  return invoiceTotal; }
  
  }
 