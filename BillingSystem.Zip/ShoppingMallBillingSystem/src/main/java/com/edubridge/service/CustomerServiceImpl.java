/*
 * package com.edubridge.service;
 * 
 * import org.springframework.beans.factory.annotation.Autowired;
 * 
 * import com.edubridge.entity.Customer; import
 * com.edubridge.repository.CustomerRepository;
 * 
 * public class CustomerServiceImpl implements CustomerService{
 * 
 * @Autowired CustomerRepository customerRepository;
 * 
 * @Override public Customer saveCustomer(Customer customer) { return
 * customerRepository.save(customer); }
 * 
 * @Override public Customer getCustomerByContactNumber(String contactNumber) {
 * // TODO Auto-generated method stub return
 * customerRepository.findById(contactNumber).get(); }
 * 
 * }
 */