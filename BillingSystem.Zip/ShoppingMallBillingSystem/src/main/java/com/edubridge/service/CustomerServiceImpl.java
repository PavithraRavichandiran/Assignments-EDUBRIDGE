
  package com.edubridge.service;
  
  import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.entity.Customer;
import com.edubridge.repository.CustomerRepository;
  @Service
  public class CustomerServiceImpl implements CustomerService{
  
  @Autowired CustomerRepository customerRepository;
  
  @Override
  public Customer saveCustomer(Customer customer) { 
	  return  customerRepository.save(customer);
  }

@Override
public List<Customer> getAllCustomers() {
	// TODO Auto-generated method stub
	return customerRepository.findAll();
}

@Override
public List<Customer> getCustomerByName(String customerName) {
	// TODO Auto-generated method stub
	return customerRepository.findByCustomerName(customerName);
}
  
  

  @Override public Customer getCustomerByContactNumber(String customerMobileNo)
  {
  
  return customerRepository.findByCustomerMobileNo(customerMobileNo);
  }

@Override
public void removeCustomer(String customerId) {
	// TODO Auto-generated method stub
	 customerRepository.deleteById(customerId);
}

@Override
public Customer updateCustomer(String customerName, Customer customer) {
	Customer customer1 =(Customer) getCustomerByName(customerName);
	
	customer1.setCustomerMobileNo(customer.getCustomerMobileNo());
	customer1.setCustomerName(customer.getCustomerName());
	return customerRepository.save(customer1);
}
  
  }
 
     